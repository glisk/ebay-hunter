# Bug Report: Price History Depth Label Shows 0 Days Incorrectly

**Date:** 2026-05-04  
**File:** `20260504-bugreport-price-history-depth-label-wrong.md`  
**Severity:** Low — cosmetic/formatting only, no data integrity impact  
**Component:** Run summary report output  

---

## Summary

The `Price history depth` row in the run summary displays `0 days` regardless of how many days of observations have actually been accumulated. The parenthetical target value is correct, but the current depth value is wrong.

---

## Observed Output

```
| Price history depth | 0 days (90 days needed for full signal) |
```

This appeared in the 2026-05-04 report despite the price history sections below it showing observations from at least two runs (yesterday and today), and the observation counts confirming data exists:

```
Price History — "5975WX workstation" (last 90 days, 23 observations)
Price History — "5945WX workstation" (last 90 days, 12 observations)
Price History — "5955WX workstation" (last 90 days, 5 observations)
```

---

## Expected Output

The label should reflect the actual number of days spanned by the oldest observation in the database:

```python
def price_history_depth_days(db):
    row = db.execute("""
        SELECT CAST(
            julianday('now') - julianday(MIN(observed_at))
        AS INTEGER)
        FROM price_observations
    """).fetchone()
    return row[0] if row and row[0] is not None else 0
```

Expected output after two days of runs:

```
| Price history depth | 1 day (90 days needed for full signal) |
```

---

## Notes

- Singular/plural handling: `1 day` not `1 days`
- If the table is empty the label should read `0 days` — that case is correct, the bug is that it reads 0 even when data exists
- The observation counts in the price history sections themselves are correct; only the summary label is wrong
