# Bug Report: SUSPICIOUS_LOW Listings Contaminating Price History Statistics

**Date:** 2026-05-04  
**File:** `20260504-bugreport-suspicious-low-contaminates-price-history.md`  
**Severity:** Medium — produces misleading market price signals  
**Component:** Price history calculation / `price_observations` table  

---

## Summary

Listings flagged `SUSPICIOUS_LOW` are being written to the `price_observations` table and included in price history statistics. This skews percentile calculations, particularly P10 and P50, producing a false impression that the market is cheaper than it actually is for that search query.

---

## Observed Evidence

From the 2026-05-04 report, the `5945WX workstation` price history section:

```
| Floor (P10) | $349   |
| Median (P50) | $1,599 |
| Observed min | $349   |
```

The $349 observation originates from this listing:

```
5SA1J36468 - Lenovo P620 Workstation AMD TR PRO 5945WX 4.1G 12C 24T Processor
Score: 63/100 (REVIEW) SUSPICIOUS_LOW
Price: $349
```

This listing is almost certainly a processor/FRU component, not a complete workstation system (note the Lenovo part number format in the title: `5SA1J36468`). The `SUSPICIOUS_LOW` flag correctly identifies it as anomalous, but the price is still flowing into the history table and pulling the P50 down from its true value of approximately $1,700 to $1,599.

For the `5955WX workstation` query, the $1,559 floor similarly reflects a Gigabyte motherboard-only listing rather than a complete system.

---

## Expected Behavior

Listings with a `SUSPICIOUS_LOW` flag should be excluded from price history observation writes entirely. The flag already encodes the judgment that this price is not representative of the market being tracked. Including it in statistics contradicts that judgment.

---

## Recommended Fix

Add a flag check before writing to `price_observations`:

```python
def record_observation(db, item_id, search_query, price, score, status="active", flags=None):
    # Do not pollute price history with anomalous listings
    if flags and "SUSPICIOUS_LOW" in flags:
        return  # skip — price is not representative of this market
    
    db.execute("""
        INSERT INTO price_observations 
            (item_id, search_query, observed_at, price, score, status)
        VALUES (?, ?, datetime('now'), ?, ?, ?)
    """, (item_id, search_query, price, score, status))
```

The listing should still appear in the scored output (REVIEW tier in this case) so the user sees it — the fix only prevents it from entering the price statistics.

---

## Secondary Recommendation

Consider logging a count of excluded observations in the run summary, e.g.:

```
| Price history depth | 1 day (90 days needed for full signal) |
| Observations excluded (SUSPICIOUS_LOW) | 2 |
```

This makes the exclusion visible and auditable without burying it.

---

## Affected Queries (as of 2026-05-04)

- `5945WX workstation` — $349 component listing pulling P10/P50 down
- `5955WX workstation` — $1,559 motherboard-only listing setting false floor
